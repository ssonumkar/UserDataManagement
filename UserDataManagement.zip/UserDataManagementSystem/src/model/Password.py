class Password:
    def __init__(self,usa,uae,prc,ind):
        self.usa=usa;
        self.uae=uae
        self.prc=prc
        self.ind=ind